package org.usfirst.frc.team4276.robot;

public class XBox {
	
	static int X=3,Y=4,A=1,B=2;
    static int LB=5,RB=6;
    static int Back=7,Start=8;
    static int LStick=9,RStick=10;


static int LStickX =6;
static int LStickY =1;
static int LTrigger = 2;
static int RTrigger = 3;
static int RStickX =4;
static int RStickY =5;
//static int PadX    =6; //No Y control


}
